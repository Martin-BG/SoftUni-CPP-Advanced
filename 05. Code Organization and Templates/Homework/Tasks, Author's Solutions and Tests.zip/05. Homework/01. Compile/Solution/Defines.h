#ifndef DEFINES_H
#define DEFINES_H

#define DONT_COMPILE_THIS
#define STANDARD_TEMPLATE_LIBRARY namespace std

#include <string>
#include <iostream>

#endif // !DEFINES_H

